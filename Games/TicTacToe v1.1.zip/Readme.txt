TicTacToe v1.1 README
=====================

Contact Me
==========

Although TicTacToe should work for almost everybody, you might run into problems.
Suggestions and comments are also welcome. If you have a beta version, grab this
one it has fixes and enhancements added since then. :)

E-mail me here: zonemaster@yahoo.com

Donations
=========

Even though ShutOff has been released as Freeware, I do accept donations
to further my program(s) development. If you wish to make a small donation
$1,$2,$5 or whatever, you can use PayPal and send me a payment using my email
zonemaster@yahoo.com as the recipient. Thank you :)       

Credits
=======

Thanks to Mike "Zbad" Jennings for turning me on to Visual Basic 5.0 :)
Special thanks to Microsoft for their ImageList and Common Dialog Controls.
IT Consultancy for their Launch Browser control (LaunchBrowser.ocx)