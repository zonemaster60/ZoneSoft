Space Patrol 1.029 beta
-----------------------

This is my first attempt at creating a vertical scrolling shooter.
I have done other games and programs in the past, but nothing like
this.

All I ask is that you try it out and give me any feedback either
negative or positive as to what you would like to see or removed.

You can press <I-key> in the main menu to display the game
instructions. I don't really need to go into this in detail,
all the controls and functions are explained there.

NOTE: If the game for some reason crashes or gives an error code
      it will be sent to a log file called 'game_errors.log'. When
      reporting bugs please include this file.

Information
-----------

Homepage: https://www.facebook.com/DavesPCPortal
Author/Developer: David Scouten
Contact: zonemaster@yahoo.com

Credits
-------

Mark Overmars: GameMaker v5.3a
Jasc Software: Paintshop Pro 8.01

